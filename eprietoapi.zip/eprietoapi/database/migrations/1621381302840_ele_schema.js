'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class EleSchema extends Schema {
  up () {
    this.create('eles', (table) => {
      table.increments()
      table.string('nombre',50)
      table.string('apellido', 50)
      table.timestamps()
    })
  }

  down () {
    this.drop('eles')
  }
}

module.exports = EleSchema
