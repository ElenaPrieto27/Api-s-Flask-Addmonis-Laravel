'use strict'

const User = use('App/Models/Ele');

class EleController {

    async store({request, response}){

        try {
            const data = await request.all();
            const usr = new User();

            usr.nombre = data.nombre;
            usr.apellido = data.apellido;

            if (await usr.save()){
                return response.status(200).json(usr);
            }

            


        }catch (error){
            return error;

        }

    }

}

module.exports = EleController
